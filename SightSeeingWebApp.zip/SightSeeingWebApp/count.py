from sqlalchemy import create_engine, text

# Kết nối đến file database của bạn
engine = create_engine("sqlite:///images.db")

def print_all_images():
    """In toàn bộ dữ liệu trong bảng images"""
    with engine.connect() as conn:
        # Thực hiện truy vấn toàn bộ bảng
        results = conn.execute(text("SELECT * FROM images")).mappings().all()

        if not results:
            print("⚠️ Database rỗng hoặc chưa có bảng 'images'.")
            return

        # In từng dòng ra console
        print("=== DỮ LIỆU TRONG BẢNG IMAGES ===")
        for row in results:
            data = dict(row)
            print("-" * 60)
            for key, value in data.items():
                print(f"{key}: {value}")
        print("-" * 60)
        print(f"✅ Tổng cộng: {len(results)} dòng dữ liệu.")

if __name__ == "__main__":
    print_all_images()
